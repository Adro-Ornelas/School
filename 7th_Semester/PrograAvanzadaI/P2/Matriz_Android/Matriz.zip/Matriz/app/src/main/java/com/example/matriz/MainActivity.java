package com.example.matriz;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private Matriz m1, m2, m3;

    private EditText inputRows, inputCols;
    private Button btnGenMatriz, btnSave;
    private Spinner spinnerTipoOp;
    private TableLayout tablaMatriz;
    private EditText[][] camposEdt;
    private TextView txvMatrizInd;
    private int rows, cols;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //-----------------Relaciona componentes con ID------------
        // Inicializa botones
        btnSave = findViewById(R.id.btnSaveMatriz);
        btnGenMatriz = findViewById(R.id.btnGenMatriz);

        // Iniciar EditText
        txvMatrizInd = findViewById(R.id.txvMatrizInd);
        inputRows = findViewById(R.id.inputRows);
        inputCols = findViewById(R.id.inputCols);

        // Inicializa lista desplegable
        spinnerTipoOp = findViewById(R.id.spinnerTipoOp);

        // Inicaliza Tabla
        tablaMatriz = findViewById(R.id.tablaMatriz);

        //--------------------Layout incial-----------------------
        // Añade opciones al spinner
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                R.array.s_array_operaciones,
                android.R.layout.simple_spinner_item
        );
        // Añadir adaptador al spinner
        spinnerTipoOp.setAdapter(adapter);

        //--------------------Eventos de botones------------------
        btnSave.setOnClickListener(v -> guardarMatriz());
        btnGenMatriz.setOnClickListener(v -> generarTabla());
    }


    private void generarTabla()
    {
        // Obtiene valores de filas y oclumnas
        String sRows = inputRows.getText().toString();
        String sCols = inputCols.getText().toString();

        if(sRows.isEmpty() || sCols.isEmpty()) {

            Toast.makeText(this, "Ingresa filas y columnas", Toast.LENGTH_SHORT).show();

        } else {

            rows = Integer.parseInt(sRows);
            cols = Integer.parseInt(sCols);

            if(rows < 1 || cols < 1 || rows > 10|| cols > 10) {

                Toast.makeText(this, "Rango entres 1 y 10", Toast.LENGTH_SHORT).show();
            } else {

                // Remueve los contenedores existentes para imprimir nuevos
                tablaMatriz.removeAllViews();

                // Establece el tamaño del arreglo de EditText
                camposEdt = new EditText[rows][cols];

                for(int i = 0; i < rows; ++i) {
                    // Nueva fila
                    TableRow fila = new TableRow(this);

                    for(int j = 0; j < cols; ++j) {
                        // Nuevo campo en la fila 'i'
                        EditText celda = new EditText(this);

                        // Hint que aparecerá en cada EditText
                        celda.setHint("[" + i + "]" + "[" + j + "]");

                        celda.setInputType(InputType.TYPE_CLASS_NUMBER);
                        celda.setEms(3);
                        // Añade el EditText en la fila
                        fila.addView(celda);

                        // Asigna el EditText al arreglo para poder acceder a él posteriormente
                        camposEdt[i][j] = celda;
                    }
                    // Añade la fila al la tabla
                    tablaMatriz.addView(fila);
                }
                // Hace visible el botón de "Guardar Valores"
                btnSave.setVisibility(View.VISIBLE);
            }
        }
    }

    private void guardarMatriz() {


        if(m1 == null) {        // Si matriz 1 no tiene valores, llena m1
            // Inicializa nuevo objeto matriz
            m1 = new Matriz(this, rows, cols);

            // Llenar objeto matriz1 (m1)
            for(int i = 0; i < rows; ++i) {
                for(int j = 0; j < cols; ++j) {
                    // Obtiene como string
                    String sValue = camposEdt[i][j].getText().toString();

                    // Llena el campo del objeto matriz (hace parseo)
                    if(!sValue.isEmpty())
                        m1.insertarCampo(i, j, Double.parseDouble(sValue));
                }
            }

            // Mostrar matriz en Log
            m1.imprimir();
            Toast.makeText(this, "Matriz 1 Guardada", Toast.LENGTH_SHORT).show();

            // Cambia aspecto de botón a Guardar y Calcular resultado
            btnSave.setText("Guardar y calcular");

            // Indica al usuario ingresar matriz 2
            txvMatrizInd.setText("Matriz 2");

            // Limpia TableLayout y limpia campos
            clearFields();

            // Hace selector de operación visible
            spinnerTipoOp.setVisibility(View.VISIBLE);
        } else
        if(m2 == null) {// Si matriz 2 no tiene valores, llena m2
            // Inicializa nuevo objeto matriz
            m2 = new Matriz(this, rows, cols);

            // Llenar objeto matriz1 (m1)
            for(int i = 0; i < rows; ++i) {
                for(int j = 0; j < cols; ++j) {
                    // Obtiene como string
                    String sValue = camposEdt[i][j].getText().toString();

                    // Llena el campo del objeto matriz (hace parseo)
                    if(!sValue.isEmpty())
                        m2.insertarCampo(i, j, Double.parseDouble(sValue));
                }
            }

            // Mostrar matriz en Log
            m2.imprimir();
            Toast.makeText(this, "Matriz 2 Guardada", Toast.LENGTH_SHORT).show();


            // Mostrar resultado en el mismo array de Edt
            // Primero evalúa tipo de operación
            operaEImprimeResultado();

        }



    }

    private void operaEImprimeResultado() {
        m3 = new Matriz(this, 10, 10);
        String selectedOper = spinnerTipoOp.getSelectedItem().toString();
        if(selectedOper.equals("Suma  (+)")) {

            m3 = m1.sumar(m2);

        } else if (selectedOper.equals("Resta (-)")) {

            m3 = m1.restar(m2);

        } else {    // Mulltiplicación

            m3 = m1.multiplicar(m2);

        }
        m3.imprimir();

        m1 = null;
        m2 = null;
    }

    private void clearFields() {
        inputRows.setText("");
        inputCols.setText("");
        tablaMatriz.removeAllViews();
    }

}