package com.example.matriz;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

public class Matriz {

    //public const int MAX = 10;
    public double[][] contenido;
    private Context context;
    private int rows;
    private int cols;

    public Matriz(Context context, int rows, int cols)
    {

        // En java si no se proporcionan estos valores, son 0 por defecto
        setSize(rows, cols);

        // Establecer context (necesario para Toast)
        this.context = context;

        //  Marca todas las casillas como 0 (valor por defecto)
        for(int r = 0; r < rows; ++r) {
            for(int c = 0; c < cols; ++c) {
                contenido[r][c] = 0;
            }
        }
    }

    //public ~Matriz(){}
    public Matriz sumar(Matriz matriz)
    {
        // La matriz resultante sería del mismo tamaño
        Matriz resultM = new Matriz(context, rows, cols);

        if(isSumable(matriz)){

            // Si es sumable, suma
            for(int r = 0; r < rows; ++r) {
                for(int c = 0; c < cols; ++c) {
                    resultM.contenido[r][c] = contenido[r][c] + matriz.contenido[r][c];
                }
            }


        } else {
            toastMsg("No es sumable");
        }
        return resultM;
    }

    public Matriz restar(Matriz matriz)
    {
        // La matriz resultante sería del mismo tamaño
        Matriz resultM = new Matriz(context, rows, cols);

        if(isSumable(matriz)){

            // Si es restable, resta
            for(int r = 0; r < rows; ++r) {
                for(int c = 0; c < cols; ++c) {
                    resultM.contenido[r][c] = contenido[r][c] - matriz.contenido[r][c];
                }
            }

        } else {
            toastMsg("No es restable");

            // El resultado tiene un tamaño de 0x0 (inválido)
            resultM.setSize(0, 0);
        }

        return resultM;
    }
    public Matriz multiplicar(Matriz matriz)
    {
       /*
        La matriz resultante tendrá el número de filas de la primera
        y el número de columnas de la segunda
        */
       Matriz resultM = new Matriz(context, rows, matriz.cols);

        if(isMultiplicable(matriz)) {

            // Guardará el resultado de la suma de multiplicaciones
            double resul_mult;

            // Si es multiplicable, multiplica
            for(int r = 0; r < rows; ++r) {
                for(int c = 0; c < matriz.cols; ++c) {

                    resul_mult = 0;
                    // Suma el proucto de filas por columa
                    for(int i = 0; i < cols; ++i) {
                        resul_mult += contenido[r][i] * matriz.contenido[i][c];
                    }

                    // Añade resultado a matriz resultante
                    resultM.contenido[r][c] = resul_mult;
                }
            }

        } else {
            toastMsg("No es multiplicable");

            // El resultado tiene un tamaño de 0x0 (inválido)
            resultM.setSize(0, 0);
        }

        return resultM;
    }

    public boolean isMultiplicable(Matriz matriz)
    {
        return (cols == matriz.rows);
    }
    public boolean isSumable(Matriz matriz)
    {
        return ((rows == matriz.rows) && (cols == matriz.cols) );
    }

    public void imprimir()
    {
        // Muestra en el LOG
        StringBuilder stringBuilder = new StringBuilder();
        for(int r = 0; r < rows; ++r){
            for(int c = 0; c < cols; ++c) {
                stringBuilder.append("[").append(contenido[r][c]).append("] ");
            }
            stringBuilder.append("\n");
        }
        Log.d("Imprimir_matriz", "\n"+ stringBuilder.toString());
        toastMsg(stringBuilder.toString());
    }

    public void llenarMatriz()
    {
        for(int r = 0; r < rows; ++r){
            for(int c = 0; c < cols; ++c) {
                toastMsg("Elemento [" + r + "][" + c + "]: ");
                //-------------------------------------------------------
                // contenido[r][c] = Convert.ToDouble(Console.ReadLine());
            }
        }
    }

    public void setSize(int rows, int cols){
        contenido = new double[rows][cols];
        this.rows = rows;
        this.cols = cols;
    }
    public int getRows(){
        return this.rows;
    }
    public int getCols(){
        return this.cols;
    }

    public void toastMsg(String message)
    {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
    }

    public void insertarCampo(int row, int col, double value)
    {
        contenido[row][col] = value;
    }
}
