package com.example.musicplayer;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.example.musicplayer.adapters.MusicListAdapter;
import com.example.musicplayer.mediaplayer.SongRepository;

import java.io.File;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    TextView txtv_noSongsFound;
    RecyclerView rv_songs;

    ArrayList<AudioModel> songsList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtv_noSongsFound = findViewById(R.id.txtv_NoSongsFound);
        rv_songs = findViewById(R.id.rv_SongsList);

        if(!checkPermission()){
            requestPermission();
            return;
        }

        String[] projection = {
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.DATA,
                MediaStore.Audio.Media.DURATION,
                MediaStore.Audio.Media.ARTIST,
                MediaStore.Audio.Media.ALBUM_ID
        };
        String selection = MediaStore.Audio.Media.IS_MUSIC + " != 0";

        Cursor cursor = getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                projection,
                selection,
                null,
                null);

        while(cursor.moveToNext()){
            // Consigue path, title y duration
            AudioModel songData = new AudioModel(cursor.getString(1),
                    cursor.getString(0),
                    cursor.getString(2),
                    cursor.getString(3),
                    cursor.getString(4));

            if(new File(songData.getPath()).exists())
                songsList.add((songData));
        }

        if(songsList.size() == 0) {
            txtv_noSongsFound.setVisibility(View.VISIBLE);
        } else {
            // recyclerview
            rv_songs.setLayoutManager(new LinearLayoutManager(this));
            rv_songs.setAdapter(new MusicListAdapter(songsList, getApplicationContext()));
        }


    }

    boolean checkPermission(){
        int result = ContextCompat.checkSelfPermission(this,
                Manifest.permission.READ_EXTERNAL_STORAGE);
        return (result == PackageManager.PERMISSION_GRANTED);
    }

    void requestPermission(){

        if(ActivityCompat.shouldShowRequestPermissionRationale(this,
                Manifest.permission.READ_EXTERNAL_STORAGE)) {
            Toast.makeText(this, "READ PERMISSION IS REQUIRED, ALLOW FROM SETTINGS",
                    Toast.LENGTH_SHORT).show();
        } else {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                    123);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        if(rv_songs != null) {

            rv_songs.scrollToPosition((SongRepository.getCurrentIndex()));
            rv_songs.setAdapter(new MusicListAdapter(songsList, getApplicationContext()));

        }
    }
}