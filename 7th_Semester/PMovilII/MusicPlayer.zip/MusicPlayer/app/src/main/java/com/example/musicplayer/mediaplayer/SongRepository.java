package com.example.musicplayer.mediaplayer;

import com.example.musicplayer.AudioModel;

import java.util.ArrayList;
import java.util.Random;

public class SongRepository {

    private static ArrayList<AudioModel> songsList;
    private static int currentIndex = -1;

    public static ArrayList<AudioModel> getSongsList() {
        return songsList;
    }

    public static void setSongsList(ArrayList<AudioModel> songsList) {
        SongRepository.songsList = songsList;
    }

    public static int getCurrentIndex() {
        return currentIndex;
    }

    public static void setCurrentIndex(int currentIndex) {
        SongRepository.currentIndex = currentIndex;
    }

    public static AudioModel getSong(int index) {
        if (songsList == null || index < 0 || index >= songsList.size())
            return null;
        return songsList.get(index);
    }

    public static AudioModel getCurrentSong() {
        return getSong(currentIndex);
    }

    // Incrementa uno evitando overflow (para skip Next) y devuelve siguiente canción
    public static AudioModel skipNext() {

        if(currentIndex == songsList.size() - 1)
            currentIndex = -1;
        currentIndex += 1;

        return getCurrentSong();
    }
    // DEcrementa uno evitando underflow (para skip Previous) y devuelve canción previa
    public static AudioModel skipPrevious() {

        if(currentIndex == 0)
            currentIndex = songsList.size();
        currentIndex -= 1;

        return getCurrentSong();
    }

    public static AudioModel skipRandom() {
        Random rand = new Random();
        int randInt;
        // Evita que sea la misma canción
        do {
            randInt = rand.nextInt(songsList.size() - 1);
        } while(randInt == currentIndex);

        // Nuevoíndice
        currentIndex = randInt;

        return getCurrentSong();
    }
}
