package com.example.musicplayer.adapters;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.musicplayer.AudioModel;
import com.example.musicplayer.PlaySong;
import com.example.musicplayer.R;
import com.example.musicplayer.mediaplayer.MyMediaPlayer;
import com.example.musicplayer.mediaplayer.SongRepository;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

public class MusicListAdapter extends RecyclerView.Adapter<MusicListAdapter.ViewHolder>{

    ArrayList<AudioModel> songsList;
    Context context;

    public MusicListAdapter(ArrayList<AudioModel> songs, Context context) {
        this.songsList = songs;
        this.context = context;
    }

    @NonNull
    @NotNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.rv_song_item, parent, false);
        return new MusicListAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull MusicListAdapter.ViewHolder holder, int position) {
        AudioModel songData = songsList.get(position);

        holder.txt_trackTitle.setText(songData.getTitle());

        // Cambiar color a la cación seleccionada
        if(SongRepository.getCurrentIndex() == position) {
            holder.txt_trackTitle.setTextColor(Color.parseColor("#9C9C9C"));
        } else {
            holder.txt_trackTitle.setTextColor(Color.parseColor("#FFFFFF"));
        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(MyMediaPlayer.getInstance() == null)
                    MyMediaPlayer.getInstance().reset();

                // Establece el índice de canción elegido
                SongRepository.setCurrentIndex(position);
                // Lleva las canciones al repositorio
                SongRepository.setSongsList(songsList);

                Intent toSong = new Intent(context, PlaySong.class);

//                // Pasa lista y data de canció
//                toSong.putExtra("LIST", songsList);
//                toSong.putExtra("INDEX", position);
                toSong.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(toSong);
            }
        });
    }

    @Override
    public int getItemCount() {
        return songsList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView txt_trackTitle;
        ImageView imv_trackImage;

        public ViewHolder(View itemView) {
            super(itemView);

            txt_trackTitle = itemView.findViewById(R.id.txtv_trackTitle);
            imv_trackImage = itemView.findViewById(R.id.imv_trackImage);

        }
    }
}
