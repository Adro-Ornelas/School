package com.example.musicplayer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentUris;
import android.content.Context;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

//import com.bumptech.glide.Glide;
import com.example.musicplayer.mediaplayer.MyMediaPlayer;
import com.example.musicplayer.mediaplayer.SongRepository;

import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

public class PlaySong extends AppCompatActivity {

    ImageView imv_songCover,
            imv_skipPrevious,
            imv_rewind,
            imv_pausePlay,
            imv_forward,
            imv_skipNext,
            imv_shuffle,
            imv_repeatSong;
    TextView txv_songTitle,
            txv_songArtist,
            txv_songCurrentTime,
            txv_songTotalTime;
    SeekBar sk_songSeekBar;

    int index;


    boolean shuffle,    // Variables para reproducción aleatoria es true
            loop;       // Para loop en la misma canción es true

    MediaPlayer mediaPlayer = MyMediaPlayer.getInstance();

    ArrayList<AudioModel> songsList;
    AudioModel currentSong;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play_song);


        // -----------------------RELACIÓN VISTA-CONTROLADOR--------------

        imv_songCover = findViewById(R.id.imv_songCover);
        imv_skipPrevious = findViewById(R.id.imv_skipPrevious);
        imv_rewind = findViewById(R.id.imv_rewind);
        imv_pausePlay = findViewById(R.id.imv_pausePlay);
        imv_forward = findViewById(R.id.imv_forward);
        imv_skipNext = findViewById(R.id.imv_skipNext);
        imv_shuffle = findViewById(R.id.imv_shuffle);
        imv_repeatSong = findViewById(R.id.imv_repeatSong);
        txv_songTitle = findViewById(R.id.txv_songTitle);
        txv_songArtist = findViewById(R.id.txv_songArtist);
        txv_songCurrentTime = findViewById(R.id.txv_songCurrentTime);
        txv_songTotalTime = findViewById(R.id.txv_songTotalTime);
        sk_songSeekBar = findViewById(R.id.sk_songSeekBar);


        // ----------------EVENTOS-------------------

        imv_skipPrevious.setOnClickListener(v -> event_skipPrevious());
        imv_rewind.setOnClickListener(v -> event_rewind());
        imv_pausePlay.setOnClickListener(v -> event_pausePlay());
        imv_forward.setOnClickListener(v -> event_forward());
        imv_skipNext.setOnClickListener(v -> event_skipNext());
        imv_shuffle.setOnClickListener(v -> event_shuffle());
        imv_repeatSong.setOnClickListener(v -> event_repeatSong());

        //--------------------INICIALIZACIÓN DE VARIABLES

        // Inicia con shuffle off (no aleatorio) y loop en una sola canción off
        shuffle = loop = false;

        // El índice de la canción ya está en el repositorio (singleton) SongsRepository
        // Recibe la canción actual
        currentSong = SongRepository.getCurrentSong();

        // Inicia canción e imprime su información
        setResorucesWithMusic();


        mediaPlayer.setOnCompletionListener(v -> songCompleted());

        PlaySong.this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if(mediaPlayer != null) {

                    // Actualiza seekBar y textView de segundos constantemente(cada 100 milis)
                    sk_songSeekBar.setProgress(mediaPlayer.getCurrentPosition());
                    txv_songCurrentTime.setText(durationToMMSS(mediaPlayer.getCurrentPosition()+""));

                }

                new Handler().postDelayed(this, 100);
            }
        });

        sk_songSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if(mediaPlayer != null && fromUser) {

                    // El usuairo ajusta la posición de la canción con la seekbar
                    mediaPlayer.seekTo(progress);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }

    private void songCompleted() {

        if(loop) {
            /*
             Si está en loop no debería ejecutarse ésta función, pero cuando
             el usuario cambia de canción el loop no se aplica a la siguiente canción,
             pero el loop sigue seleccionado, por eso vuelve a aplicar loop.
             */
            mediaPlayer.start();
            mediaPlayer.setLooping(true);
        } else {
            event_skipNext();
        }


    }

    private void playMusic() {

        mediaPlayer.reset();

        try {
            mediaPlayer.setDataSource(currentSong.getPath());
            mediaPlayer.prepare();
            mediaPlayer.start();

            sk_songSeekBar.setProgress(0);
            sk_songSeekBar.setMax(mediaPlayer.getDuration());

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void event_repeatSong() {

        if(loop) {
            // Stop loop
            imv_repeatSong.setImageResource(R.drawable.ic_baseline_repeat);
            mediaPlayer.setLooping(false);

        } else {

            // Start in loop
            mediaPlayer.setLooping(true);

            imv_repeatSong.setImageResource(R.drawable.ic_baseline_repeat_one);
        }

        // Toggle value
        loop = !loop;

    }

    private void event_shuffle() {

        if(shuffle) {
            // Stop shuffle
            imv_shuffle.setImageResource(R.drawable.ic_baseline_shuffle_off);

        } else {
            // Start shuffle
            imv_shuffle.setImageResource(R.drawable.ic_baseline_shuffle);
        }

        // Toggle value
        shuffle = !shuffle;

    }

    private void event_skipNext() {

        if(shuffle)
            currentSong = SongRepository.skipRandom();
        else
            currentSong = SongRepository.skipNext();

        mediaPlayer.reset();

        // Para actualizar título y duración
        setResorucesWithMusic();

    }

    private void event_skipPrevious() {

        if(shuffle)
            currentSong = SongRepository.skipRandom();
        else
            currentSong = SongRepository.skipPrevious();

        mediaPlayer.reset();
        // Para actualizar título y duración
        setResorucesWithMusic();
    }

    private void event_forward() {

        // Suma 5 segundos
        mediaPlayer.seekTo(mediaPlayer.getCurrentPosition() + 5000);
    }

    private void event_pausePlay() {

        if(mediaPlayer.isPlaying()) {

            // Pausa canción
            mediaPlayer.pause();
            // Pone imagen de play
            imv_pausePlay.setImageResource(R.drawable.ic_baseline_play_arrow);

        } else {

            // Inicia canción
            mediaPlayer.start();
            // Pone imagen de pausa
            imv_pausePlay.setImageResource(R.drawable.ic_baseline_pause);

        }

    }

    private void event_rewind() {

        // SResta 5 segundos
        mediaPlayer.seekTo(mediaPlayer.getCurrentPosition() - 5000);
    }


    private void setResorucesWithMusic() {


//        currentSong = (AudioModel) songsList.get(MyMediaPlayer.currentIndex);
        txv_songTitle.setText(currentSong.getTitle());
        txv_songTotalTime.setText(durationToMMSS(currentSong.getDuration()));
        txv_songArtist.setText(currentSong.getArtist());

//        Uri albumUri = getAlbumArtUri(this, Integer.parseInt(currentSong.getAlbum_id()));
//        Glide.with(this)
//                .load(albumUri)
//                .error(R.drawable.ic_baseline_music_note)
//                .into(imv_songCover);


        //.placeholder(R.drawable.placeholder)


        // Inicia canción
        playMusic();
    }
    public Uri getAlbumArtUri(Context context, long albumId) {
        Uri sArtworkUri = Uri.parse("content://media/external/audio/albumart");
        return ContentUris.withAppendedId(sArtworkUri, albumId);
    }




    public static String durationToMMSS(String duration) {
        Long millis = Long.parseLong(duration);
        return String.format("%02d:%02d",
                TimeUnit.MILLISECONDS.toMinutes(millis) % TimeUnit.HOURS.toMinutes(1),
                TimeUnit.MILLISECONDS.toSeconds(millis) % TimeUnit.MINUTES.toSeconds(1));
    }

    @Override
    protected void onPause() {
//
//        mediaPlayer.stop();
//        finish();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
//
//        if(mediaPlayer != null) {
//            // Libera objeto MediaPlayer
//            mediaPlayer.release();
//            mediaPlayer = null;
//        }
//
        super.onDestroy();
    }
}