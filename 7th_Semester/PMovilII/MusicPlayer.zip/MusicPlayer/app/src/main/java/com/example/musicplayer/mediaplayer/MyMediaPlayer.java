package com.example.musicplayer.mediaplayer;

// Helper class to use MediaPlayer from any class

import android.media.MediaPlayer;

public class MyMediaPlayer {
    static MediaPlayer instance;

    public static MediaPlayer getInstance(){
        if(instance == null) {
            instance = new MediaPlayer();
        }
        return instance;
    }
}
