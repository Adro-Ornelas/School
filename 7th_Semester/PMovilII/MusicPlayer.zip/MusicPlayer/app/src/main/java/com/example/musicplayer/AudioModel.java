package com.example.musicplayer;

import java.io.Serializable;

public class AudioModel implements Serializable {

    String path;
    String title;
    String duration;
    String artist;

    public String getAlbum_id() {
        return album_id;
    }

    public void setAlbum_id(String album_id) {
        this.album_id = album_id;
    }

    String album_id;

    public AudioModel(String path, String title, String duration, String artist, String album_id) {
        this.path = path;
        this.title = title;
        this.duration = duration;
        this.artist = artist;
        this.album_id = album_id;

    }

    public String getArtist() {
        return artist;
    }

    public void setArtist(String artist) {
        this.artist = artist;
    }
    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }
}
