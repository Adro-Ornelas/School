package com.example.geovasha;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.google.android.gms.location.Geofence;
import com.google.android.gms.location.GeofencingEvent;

public class GeofenceBroadcastReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {

        GeofencingEvent event = GeofencingEvent.fromIntent(intent);

        if (event.hasError()) {
            Log.e("GEOFENCE", "Error: " + event.getErrorCode());
            return;
        }

        int transition = event.getGeofenceTransition();

        switch (transition) {
            case Geofence.GEOFENCE_TRANSITION_ENTER:
                Log.i("GEOFENCE", "ENTRÓ a la zona");
                break;

            case Geofence.GEOFENCE_TRANSITION_EXIT:
                Log.i("GEOFENCE", "SALIO de la zona");
                break;

            case Geofence.GEOFENCE_TRANSITION_DWELL:
                Log.i("GEOFENCE", "PERMANECE dentro de la zona");
                break;
        }
    }
}
