package com.example.arduinobluetooth;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.os.AsyncTask;
import java.io.IOException;
import java.util.ArrayList;
import java.util.UUID;

public class BTControl extends AppCompatActivity
{
    ImageButton
            btnSendMessageBT,
            btnToggleLight,
            btnPrevious,
            btnPlayPause,
            btnNext;
    Button btnDisconnect;

    ImageView imageViewAlbumArt;

    EditText edtMessageBT;

    boolean lightBulbOn = false;
    boolean isPlaying = false;

    private ArrayList<Integer> listaImagenes = new ArrayList<>();
    private int indexListaImg = 0;

    String address = null;
    private ProgressDialog progress;
    BluetoothAdapter myBluetooth = null;
    BluetoothSocket btSocket = null;
    private boolean isBtConnected = false;
    static final UUID myUUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bt_control);

        //receive the address of the bluetooth device
        Intent newint = getIntent();
        // Obtiene la dirección MAC del dispositivo BT a conectar
        address = newint.getStringExtra("EXTRA_ADDRESS");

        // Relaciona objetos con su ID
        btnSendMessageBT = findViewById(R.id.btnSendMessage);
        btnToggleLight = findViewById(R.id.btnToggleLight);
        btnPrevious = findViewById(R.id.btnPrevious);
        btnPlayPause = findViewById(R.id.btnPlayPause);
        btnNext = findViewById(R.id.btnNext);
        btnDisconnect = findViewById(R.id.btnDisconnect);

        imageViewAlbumArt = findViewById(R.id.ImvAlbumArt);

        edtMessageBT = findViewById(R.id.edtMessageBT);

        // Añadir imágnes al array list de ID de imágenes
        listaImagenes.add(R.drawable.cover_pacman);
        listaImagenes.add(R.drawable.cover_tetris);
        listaImagenes.add(R.drawable.cover_beethoven);
        listaImagenes.add(R.drawable.cover_super_mario_bros);

        // Añade eventos a los botones
        btnSendMessageBT.setOnClickListener(v -> sendMessageBT());
        btnToggleLight.setOnClickListener(v -> toggleLightBT());
        btnPrevious.setOnClickListener(v -> previousTrack());
        btnPlayPause.setOnClickListener(v -> playPauseMusic());
        btnNext.setOnClickListener(v -> nextTrack());
        btnDisconnect.setOnClickListener(v -> disconnectBT());

        new ConnectBT().execute(); //Call the class to connect
    }

    private void previousTrack()
    {
        // Code: ?PT
        // Envía a Bluetooth
        if (btSocket!=null) {
            try {
                btSocket.getOutputStream().write("?PT".getBytes());
            } catch (IOException e) {
                msg("Error");
            }
        }

        // Disminuye index y si evita que se salga de rango
        --indexListaImg;
        if(indexListaImg < 0)
            indexListaImg = listaImagenes.size() - 1;
        imageViewAlbumArt.setImageResource(listaImagenes.get(indexListaImg));
    }

    private void playPauseMusic()
    {

        if(isPlaying) { // Cuando ya se estaba reproduciendo

            // Cambia apariencia de botón a play
            btnPlayPause.setImageResource(R.drawable.ic_baseline_play_arrow);

            // Code: ?ST
            // Stop Track
            if (btSocket!=null) {
                try {
                    btSocket.getOutputStream().write("?ST".getBytes());
                } catch (IOException e) {
                    msg("Error");
                }
            }

        } else {        // Cuando no había nada en reproducción

            // Cambia apariencia de botón a pausa
            btnPlayPause.setImageResource(R.drawable.ic_baseline_pause);

            // Si no había ninguna carátula cargada, carga la de PACMAN (primera)
            if(imageViewAlbumArt.getTag().equals("album")) {
                imageViewAlbumArt.setImageResource(listaImagenes.get(indexListaImg));
                imageViewAlbumArt.setTag("album_u");
            }

            // Code: ?PM
            // Play music
            if (btSocket!=null) {
                try {
                    btSocket.getOutputStream().write("?PM".getBytes());
                } catch (IOException e) {
                    msg("Error");
                }
            }
        }

        isPlaying = !isPlaying;

    }

    private void toggleLightBT()
    {

        // Los comandos siempre inician con ?
        String commandToggle = "?";
        if(lightBulbOn) {
            commandToggle += "TF";   // Si estaba prendido, apaga

            // Cambia de estado el botón a apagado
            btnToggleLight.setImageResource(R.drawable.foco_off);

        } else {
            commandToggle += "TO";   // Si estaba apagado, enciende

            // Cambia de estado el botón a encendido
            btnToggleLight.setImageResource(R.drawable.foco_on);
        }
        // Cambia estado de variable
        lightBulbOn = !lightBulbOn;

        // Envía a Bluetooth
        if (btSocket!=null) {
            try {

                btSocket.getOutputStream().write(commandToggle.getBytes());

            } catch (IOException e) {
                msg("Error");
            }
        }
    }

    private void nextTrack()
    {

        // Code: ?NT
        // Envía a Bluetooth
        if (btSocket!=null) {
            try {
                btSocket.getOutputStream().write("?NT".getBytes());
            } catch (IOException e) {
                msg("Error");
            }
        }

        // Disminuye index y si evita que se salga de rango
        ++indexListaImg;
        if(indexListaImg >= listaImagenes.size())
            indexListaImg = 0;
        imageViewAlbumArt.setImageResource(listaImagenes.get(indexListaImg));
    }

    private void disconnectBT()
    {
        if (btSocket!=null) { // Si el socket está ocupado
            try
            {
                btSocket.close(); //close connection
            }
            catch (IOException e)
            {
                msg("Error");
            }
        }
        msg("Dispositivo desconectado");
        finish(); //return to the first layout
    }

    private void sendMessageBT()
    {
        String sMessageBT = edtMessageBT.getText().toString();
        if (btSocket!=null) {
            try {

                // Se envia el string contenido en el EditText por bluetooth
                btSocket.getOutputStream().write(sMessageBT.getBytes());

            } catch (IOException e) {

                msg("Error");

            }
        }

        // Limpia campo de texto

        edtMessageBT.setText("");
    }

    private void msg(String s) {

        Toast.makeText(getApplicationContext(),s,Toast.LENGTH_LONG).show();

    }

    private class ConnectBT extends AsyncTask<Void, Void, Void>  // UI thread
    {
        private boolean ConnectSuccess = true; //if it's here, it's almost connected

        @Override
        protected void onPreExecute()
        {
            progress = ProgressDialog.show(BTControl.this, "Connecting...", "Por favor, espere!");  //show a progress dialog
        }

        @Override
        protected Void doInBackground(Void... devices) //while the progress dialog is shown, the connection is done in background
        {
            try
            {
                if (btSocket == null || !isBtConnected)
                {
                    myBluetooth = BluetoothAdapter.getDefaultAdapter();//get the mobile bluetooth device
                    BluetoothDevice dispositivo = myBluetooth.getRemoteDevice(address);//connects to the device's address and checks if it's available
                    btSocket = dispositivo.createInsecureRfcommSocketToServiceRecord(myUUID);//create a RFCOMM (SPP) connection
                    BluetoothAdapter.getDefaultAdapter().cancelDiscovery();
                    btSocket.connect();//start connection
                }
            }
            catch (IOException e)
            {
                ConnectSuccess = false;//if the try failed, you can check the exception here
            }
            return null;
        }
        @Override
        protected void onPostExecute(Void result) //after the doInBackground, it checks if everything went fine
        {
            super.onPostExecute(result);

            if (!ConnectSuccess)
            {
                msg("Connection Failed. Is it a SPP Bluetooth? Try again.");
                finish();
            }
            else
            {
                msg("Connected");
                isBtConnected = true;
            }
            progress.dismiss();
        }
    }
}