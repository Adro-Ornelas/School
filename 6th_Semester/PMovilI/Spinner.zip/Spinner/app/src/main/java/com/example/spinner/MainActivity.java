package com.example.spinner;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText edt1, edt2;
    Spinner spinner;
    TextView txtv1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edt1 = findViewById(R.id.edt_1);
        edt2 = findViewById(R.id.edt_2);
        spinner = findViewById(R.id.spinner1);
        txtv1 = findViewById(R.id.txtv1);

        // Array adapter del spinner (interfaz entre texto y vista)
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                R.array.opciones,       // Opciones en un array en strings.xml
                R.layout.spinner);      // Spinner personalizado en spinner.xml
        spinner.setAdapter(adapter);
    }

    @SuppressLint("SetTextI18n")
    public void calcular(View view) {

        String val1S, val2S;
        val1S = edt1.getText().toString();
        val2S = edt2.getText().toString();

        if(val1S.isEmpty() || val2S.isEmpty()) {

            Toast.makeText(this, "NECESITO DOS VALORES", Toast.LENGTH_LONG).show();

        } else {

            // Parsea
            double val1, val2;
            val1 = Double.parseDouble(val1S);
            val2 = Double.parseDouble(val2S);

            String opcion = spinner.getSelectedItem().toString();

            double resultado = 0;
            switch (opcion) {
                case "SUMA":
                    resultado = val1 + val2;
                    break;

                case "RESTA":
                    resultado = val1 - val2;
                    break;

                case "DIVISIÓN":
                    resultado = val1 / val2;
                    break;

                case "MULTIPLICACIÓN":
                    resultado = val1 * val2;
                    break;
                default:
                    break;
            }
            txtv1.setText("Resultado:\n" + resultado);


        }

    }
}