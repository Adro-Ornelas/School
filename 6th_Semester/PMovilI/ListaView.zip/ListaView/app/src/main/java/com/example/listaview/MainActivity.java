package com.example.listaview;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView txtv;
    ListView listv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtv = findViewById(R.id.textv);
        listv = findViewById(R.id.listv);

        String [] alumnos = {
                "Adro Ornelas", "Fernando Rodriguez", "Ariadna Castro", "Anna Lozano",
                "Amabeli Salinas", "Alondra Mendoza", "Mayra Quintero", "Miguel Servin"};

        int[] registro = {
                22300918, 21301045, 22300856, 22300953,
                22300861, 22300901, 22100149, 22100216};

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                this,
                R.layout.listviewp,
                alumnos);

        listv.setAdapter(adapter);

        listv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                txtv.setText("El alumno es " + alumnos[position] +
                            "\ncon registro " + registro[position]);

            }
        });
    }
}