package com.example.suma;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {
    Toolbar toolbar;
    EditText  val1, val2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);     // Método que dice con cuál layout se trabaja

        val1 = findViewById(R.id.edt_1);
        val2 = findViewById(R.id.edt_2);
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if(item.getItemId() == R.id.opt1) {
            Toast.makeText(this, "Ya estás en principal", Toast.LENGTH_SHORT).show();

        } else if (item.getItemId() == R.id.opt2) {
            Intent aCreador = new Intent(this, Creador.class);
            startActivity(aCreador);

        } else if (item.getItemId() == R.id.opt3) {
            Intent aContacto = new Intent(this, Contacto.class);
            startActivity(aContacto);
        }
        return super.onOptionsItemSelected(item);
    }
    public void sumar(View view) {

        Intent intentSecond = new Intent(this, SecondActivity.class);

        String sval1, sval2; // Como editText recibe strings
        double dval1, dval2;

        sval1 = val1.getText().toString();   // Lee valor 1 como string
        sval2 = val2.getText().toString();   // Lee valor 2 como string

        if(sval1.isEmpty() || sval2.isEmpty()) {

            Toast.makeText(this, "Es necesario introducir dos valores", Toast.LENGTH_LONG).show();

        } else {
            intentSecond.putExtra("sval1", sval1);
            intentSecond.putExtra("sval2", sval2);
            startActivity(intentSecond);
        }

    }
}