package com.example.suma;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

public class Contacto extends AppCompatActivity {
    Toolbar toolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contacto);

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if(item.getItemId() == R.id.opt1) {
            Intent aMain = new Intent(this, MainActivity.class);
            startActivity(aMain);

        } else if (item.getItemId() == R.id.opt2) {
            Intent aCreador = new Intent(this, Creador.class);
            startActivity(aCreador);

        } else if (item.getItemId() == R.id.opt3) {
            Toast.makeText(this, "Ya estás en contacto", Toast.LENGTH_SHORT).show();

        }
        return super.onOptionsItemSelected(item);
    }
}