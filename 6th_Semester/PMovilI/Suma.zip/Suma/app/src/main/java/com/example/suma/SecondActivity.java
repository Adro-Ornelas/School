package com.example.suma;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class SecondActivity extends AppCompatActivity {
    Toolbar toolbar;
    TextView txt1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        txt1 = findViewById(R.id.txtres);

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        alStart();
    }
    public void alStart(){

        // Obtiene valores de la primera activity
        String sval1 = getIntent().getStringExtra("sval1");
        String sval2 = getIntent().getStringExtra("sval2");

        double dval1, dval2, res;
        // Parsea
        dval1 = Double.parseDouble(sval1);
        dval2 = Double.parseDouble(sval2);

        res = dval1 + dval2;

        txt1.setText("" + res); // Imprime en la etiqueta (TextView)

    }

    public void goMainb(View view) {
        // Cuando boton regresar, se inicia la MainActivity
        Intent aMain = new Intent(this, MainActivity.class);
        startActivity(aMain);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if(item.getItemId() == R.id.opt1) {
            Toast.makeText(this, "Ya estás en principal", Toast.LENGTH_SHORT).show();

        } else if (item.getItemId() == R.id.opt2) {
            Intent aCreador = new Intent(this, Creador.class);
            startActivity(aCreador);

        } else if (item.getItemId() == R.id.opt3) {
            Intent aContacto = new Intent(this, Contacto.class);
            startActivity(aContacto);
        }
        return super.onOptionsItemSelected(item);
    }

}