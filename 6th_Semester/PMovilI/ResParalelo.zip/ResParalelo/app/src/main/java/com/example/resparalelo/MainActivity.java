package com.example.resparalelo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    // Declaración de objetos
    TextView stat_1;
    EditText edt_1, edt_2;
    TextView prompt_1, txt_VOhm;
    Toolbar toolbar;

    double vEnt = 0;    // Voltaje de entrada
    double[] resistors = new double[8]; // Arreglo para guardar de 2 a 8 resistencias
    int indRes = 0;     // Índice para el arreglo de resistencias

    // Para redondear doubles a dos cecimales
    DecimalFormat dformat = new DecimalFormat("#.##");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Asingar id de objeto a objetos
        edt_1    = findViewById(R.id.editText_1);
        edt_2    = findViewById(R.id.editText_2);
        prompt_1 = findViewById(R.id.textViewPrompt);
        txt_VOhm = findViewById(R.id.textViewVOhm);
        stat_1 = findViewById(R.id.textViewStat);

        // Toolbar
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if(item.getItemId() == R.id.opt1) {
            Toast.makeText(this, "Ya estás en principal", Toast.LENGTH_SHORT).show();

        } else if (item.getItemId() == R.id.opt2) {
            Intent aCreador = new Intent(this, Creador.class);
            startActivity(aCreador);

        } else if (item.getItemId() == R.id.opt3) {
            Intent aContacto = new Intent(this, Contacto.class);
            startActivity(aContacto);
        }
        return super.onOptionsItemSelected(item);
    }

    // @SuppressLint("SetTextI18n")    // Para imprimir cadenas
    @SuppressLint("SetTextI18n")
    public void siguienteR(View view) {


        String sValor1;    // Guardará valor string de entrada edt_1
        double dValor1;    // Guardará valor decimal de entrada edt_1

        sValor1 = edt_1.getText().toString();  // Lee valor de edt_1

        if(sValor1.isEmpty()) {   // Si la cadena está vacia, nada se ingresó a edt_1, nada por hacer

            Toast.makeText(this, "Ingresa más valores", Toast.LENGTH_LONG).show();

        } else {

            dValor1 = Double.parseDouble(sValor1);    // Parsea a double

            // Cuando Vent ya está definido
            if (indRes >= 8) { // Si ya se tienen todas las resistencias nada que hacer
                Toast toast = Toast.makeText(this, "Ya son 8 resistencias", Toast.LENGTH_LONG);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();

            } else {

                // El primer valor que se recibe al presionar siguiente es Vent, después las resistencias
                if (vEnt == 0) {  // Cuando el voltaje de entrada no se ha definido
                    if (dValor1 <= 0) {    // Cuando no es válido

                        Toast.makeText(this, "VALOR INVÁLIDO DE VOLTAJE", Toast.LENGTH_LONG).show();

                    } else {            // Cuando sí es válido
                        vEnt = dValor1;   // Se establece vEnt
                        prompt_1.setText("Introduce resistencia 1");    // Pide primera resistencia
                        stat_1.setText(stat_1.getText() + "\nVent = "); // Imprime etiqueta Vent
                        printValorMin(vEnt, 'V');      // Imprime Vent
                        txt_VOhm.setText("\u2126");   // Actualiza la etiqueta de unidad a omega
                        // Limpia campos
                        edt_1.setText("");
                        edt_2.setText("");
                        // Cambia hint de "Voltaje" a "Resistencia"
                        edt_1.setHint("Resistencia");
                    }

                } else {

                    // Verifica valor de resistencia
                    /*  Valida que dValor1 sea un valor comercial de resistencia
                        Como solo existen los valores comerciales de
                        1, 1.2, 1.5, 1.8, 2.2, 2.7, 3.3, 3.9, 3.4, 5.1, 5.6, 6.8, 8.2 y 10
                        multiplicados por potencias desde 10^0 hasta 10^6
                        el valor recibido dividido sobre 10 hasta quedar solo unidades y parte flotante
                        deberá ser alguno de estos valores
                    */
                    double dValor1Unidad = dValor1;

                    while (dValor1Unidad >= 10)
                        dValor1Unidad /= 10.0;   // Divide entre 10 hasta expresión mínima

                    if ( !(1 == dValor1Unidad || 1.2 == dValor1Unidad || 1.5 == dValor1Unidad ||
                        1.8 == dValor1Unidad  || 2.2 == dValor1Unidad || 2.7 == dValor1Unidad ||
                        3.3 == dValor1Unidad  || 3.9 == dValor1Unidad || 4.7 == dValor1Unidad ||
                        5.1 == dValor1Unidad  || 5.6 == dValor1Unidad || 6.8 == dValor1Unidad ||
                        8.2 == dValor1Unidad) ) {

                        Toast.makeText(this, "VALOR DE RESISTENCIA INVÁLIDO", Toast.LENGTH_LONG).show();

                    } else {
                        // Valida que el prefijo sea válido
                        String sPre;                                        // Guardará valor string de prefijo
                        sPre = edt_2.getText().toString();                  // Lee valor de prefijo

                        // Multiplipa por prefijo y aumenta ínidice del arreglo de resistencias

                        if(! ((sPre.equals("") || sPre.equals(" ") )||
                             (sPre.equals("k") || sPre.equals("K")) ||
                             (sPre.equals("m") || sPre.equals("M")) ) ) {

                            Toast.makeText(this, "PREFIJO INVÁLIDO", Toast.LENGTH_LONG).show();
                        } else {

                            // Ya se sabe que el prefijo es válido, ahora revisa cuál prefijo es
                            if ((sPre.isEmpty() || sPre.equals(" ")) ) {
                                // Sin prefijo
                                resistors[indRes++] = (dValor1);          // Sin prefijo es 10^0

                            } else if ((sPre.equals("k") || sPre.equals("K")) ) {
                                // Kilo
                                resistors[indRes++] = (dValor1 * 1000);   // Kilo es 10^3

                            } else {
                                // Mega
                                resistors[indRes++] = (dValor1 * 1000000); // Mega es 10^6
                            }

                            // Si el programa llegó a aquí, el valor de resistencia fue recibido correctamente

                            // Valida que no se mayor a 10M
                            if(resistors[indRes - 1] > 10000000) {

                                --indRes;   // Descarta valor
                                Toast.makeText(this, "VALOR INVÁLIDO", Toast.LENGTH_LONG).show();

                            } else {

                                // Imprime resistencia recibida
                                char saltotab;
                                if (indRes % 3 == 0)     // Cada tres resistencias salto de línea
                                    saltotab = '\n';    // Si no, tabulador, esto con el objeto de imprimir en dos columnas
                                else
                                    saltotab = '\t';

                                // Imprime número de resistencia
                                stat_1.setText(stat_1.getText().toString() + saltotab + " R" + indRes + " = ");
                                // Imprime resistenca en expresión mínima
                                printValorMin(resistors[indRes - 1], '\u2126');

                                // Pide siguiente resistencia
                                prompt_1.setText("Introduce resistencia " + (indRes + 1));

                                if (indRes == 8)
                                    prompt_1.setText("");       // Cuando se ingresó la última reistencia, limpia prompt
                            }
                        }
                    }
                }
            }
        }
    }

    @SuppressLint("SetTextI18n")
    public void finalizar(View view) {  // Función que calcula e imprime valores

        if(indRes <=1){     // Cuando hay menos de 2 resistencias definidas
            Toast.makeText(this, "SE NECESITAN MÁS DATOS", Toast.LENGTH_LONG).show();

        } else {

            if (indRes == 9) {     // Cuando el cálculo ya había sido realizado, reinicia valores
                vEnt = 0;
                indRes = 0;
                stat_1.setText("");
                prompt_1.setText("Introduce el voltaje de entrada:");
                txt_VOhm.setText("V");
                edt_1.setHint("Volaje");

            } else {

                Intent intentSecond = new Intent(this, SecondActivity.class);

                // Pasa todos los datos a segunda activity
                intentSecond.putExtra("resistors", resistors);
                intentSecond.putExtra("indRes", indRes);
                intentSecond.putExtra("vEnt", vEnt);

                startActivity(intentSecond);

                // Aquí antes estaban los cálculos

                indRes = 9; // Hace flag para indicar que ya se hicieron los cálculos
            }
        }
    }

    @SuppressLint("SetTextI18n")
    public void printValorMin(double valor, char unidad) {
        // Función que imprime con prefijo en expresión mínima cualquier valor con unidad

        char prefijo;
        if(valor >= 1000000) {          // Mega
            prefijo = 'M';
            valor /= 1000000;
        } else if (valor >= 1000) {      // Kilo
            prefijo = 'K';
            valor /= 1000;
        } else if (valor >= 1) {        // Sin prefijo
            prefijo = ' ';
        } else if(valor >= 0.001) {     // mili
            prefijo = 'm';
            valor *= 1000;
        } else { // micro u
            prefijo = '\u00B5';
               valor *= 1000000;
        }
        stat_1.setText(stat_1.getText() + dformat.format(valor) + prefijo + unidad);
    }
}
