package com.example.resparalelo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;

public class SecondActivity extends AppCompatActivity {
    Toolbar toolbar;
    TextView stat_1;


    // Para redondear doubles a dos cecimales
    DecimalFormat dformat = new DecimalFormat("#.##");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        stat_1   = findViewById(R.id.textViewStat);

        calcular();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if(item.getItemId() == R.id.opt1) {
            Toast.makeText(this, "Ya estás en principal", Toast.LENGTH_SHORT).show();

        } else if (item.getItemId() == R.id.opt2) {
            Intent aCreador = new Intent(this, Creador.class);
            startActivity(aCreador);

        } else if (item.getItemId() == R.id.opt3) {
            Intent aContacto = new Intent(this, Contacto.class);
            startActivity(aContacto);
        }
        return super.onOptionsItemSelected(item);
    }

    public void calcular() {

        double[] resistors = new double[8];
        int indRes;
        double vEnt;
        resistors = getIntent().getDoubleArrayExtra("resistors");
        indRes = getIntent().getIntExtra("indRes", 0);
        vEnt = getIntent().getDoubleExtra("vEnt", 0);


        // Calcula resistencia total RT = 1 / (1 / R1 + 1 / R2 + ... + 1 / Rn)
        double rT = 0;
        stat_1.setText(stat_1.getText().toString() + "\nRt = 1 / (");
        for (int i = 0; i < indRes; ++i) {
            rT += 1.0 / resistors[i];
            stat_1.setText(stat_1.getText().toString() + "1/");   // Imprime cada valor de res
            printValorMin(resistors[i], '\u2126');
            if (i < indRes - 1)
                stat_1.append(" + ");       // Para evitar el signo de '+' al final
        }
        rT = 1.0 / rT;
        stat_1.setText(stat_1.getText().toString() + ") = ");
        printValorMin(rT, '\u2126');    // Imprime en expresión mínima

        //  Variable para corrientes
        double amp;
        // Calula e imprime corriente maxima, usa la misma rT como variable de It
        amp = vEnt / rT;
        stat_1.setText(stat_1.getText().toString() + "\nIt = ");
        printValorMin(vEnt, 'V');
        stat_1.setText(stat_1.getText().toString() + " / ");
        printValorMin(rT, '\u2126');
        stat_1.setText(stat_1.getText().toString() + " = ");
        printValorMin(amp, 'A');

        // Usa amp definido anteriormente para cada corriente
        double pow; // Para potencia
        for (int i = 0; i < indRes; ++i) {

            // Calcula  e imprime corrientes con Ley de Ohm I = V / R con su procedimiento
            amp = (double) vEnt / resistors[i];
            stat_1.setText(stat_1.getText().toString() + "\nI" + (i + 1) + " = ");
            printValorMin(vEnt, 'V');
            stat_1.setText(stat_1.getText().toString() + " / ");
            printValorMin(resistors[i], '\u2126');
            stat_1.setText(stat_1.getText().toString() + " = ");
            printValorMin(amp, 'A');    // Imprime valor mínimo de corriente

            // Calcula e imprime potencias con P = IV con su procedimiento
            pow = amp * vEnt;
            stat_1.setText(stat_1.getText().toString() + "\nP" + (i + 1) + " = ");
            printValorMin(vEnt, 'V');
            stat_1.setText(stat_1.getText().toString() + " * ");
            printValorMin(amp, 'A');
            stat_1.setText(stat_1.getText().toString() + " = ");
            printValorMin(pow, 'W');    // Imprime valor mínimo de corriente
            }

    }

    public void goMainb(View view) {
        // Cuando boton regresar, se inicia la MainActivity
        Intent aMain = new Intent(this, MainActivity.class);
        startActivity(aMain);
    }

    public void printValorMin(double valor, char unidad) {
        // Función que imprime con prefijo en expresión mínima cualquier valor con unidad

        char prefijo;
        if(valor >= 1000000) {          // Mega
            prefijo = 'M';
            valor /= 1000000;
        } else if (valor >= 1000) {      // Kilo
            prefijo = 'K';
            valor /= 1000;
        } else if (valor >= 1) {        // Sin prefijo
            prefijo = ' ';
        } else if(valor >= 0.001) {     // mili
            prefijo = 'm';
            valor *= 1000;
        } else { // micro u
            prefijo = '\u00B5';
            valor *= 1000000;
        }
        stat_1.setText(stat_1.getText() + dformat.format(valor) + prefijo + unidad);
    }
}