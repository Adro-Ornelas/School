package Adaptadores;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.dental.R;

import org.jetbrains.annotations.NotNull;

import Global.Info;

public class adaptadoreliminar extends RecyclerView.Adapter<adaptadoreliminar.MiniActivity>{
    public Context context;

    @NonNull
    @NotNull
    @Override
    public MiniActivity onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {

        View myVer = View.inflate(context, R.layout.eliminar_view_holder, null);
        adaptadoreliminar.MiniActivity miniMini = new adaptadoreliminar.MiniActivity(myVer);

        return miniMini;
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull adaptadoreliminar.MiniActivity miactivity, int position) {

        final int pos = position;
        miactivity.editText1.setText(Info.listaDato.get(position).getNombre());
        miactivity.seleccion.setChecked(false);       // CheckBox no seleccionado por predeterminado
        miactivity.seleccion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(miactivity.seleccion.isChecked())
                    Info.listasBajas.add(Info.listaDato.get(pos));
                else
                    Info.listasBajas.remove(Info.listaDato.get(pos));
            }
        });
    }

    @Override
    public int getItemCount() {
        return Info.listaDato.size();
    }

    public class MiniActivity extends RecyclerView.ViewHolder {
        TextView editText1;
        CheckBox seleccion;
        public MiniActivity(@NonNull @NotNull View itemView) {
            super(itemView);
            editText1 = (TextView) itemView.findViewById(R.id.textvHolderDel1);
            seleccion = (CheckBox) itemView.findViewById(R.id.checkCaja1);

        }
    }
}
