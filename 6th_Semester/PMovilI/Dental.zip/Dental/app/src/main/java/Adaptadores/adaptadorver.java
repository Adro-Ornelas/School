package Adaptadores;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.dental.CardView;
import com.example.dental.R;

import Global.Info;


public class adaptadorver extends RecyclerView.Adapter<adaptadorver.MiniActivity> {
    public Context context;

    @NonNull
    @org.jetbrains.annotations.NotNull

    @Override
    public adaptadorver.MiniActivity onCreateViewHolder(@NonNull @org.jetbrains.annotations.NotNull ViewGroup parent, int viewType) {

        View myVer = View.inflate(context, R.layout.mivista, null);
        MiniActivity miniMini = new MiniActivity(myVer);
        return miniMini;
    }

    @Override
    public void onBindViewHolder(@NonNull @org.jetbrains.annotations.NotNull adaptadorver.MiniActivity miniactivity, int i) {
        final int pos = i;

        miniactivity.edtName.setText(Info.listaDato.get(i).getNombre());
        miniactivity.edtApellp.setText(Info.listaDato.get(i).getApellidoP());

        miniactivity.edtName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent aCardView = new Intent(context, CardView.class);
                aCardView.putExtra("pos", pos);
                context.startActivity(aCardView);
            }
        });
    }

    @Override
    public int getItemCount() {
        return Info.listaDato.size();
    }

    public class MiniActivity extends RecyclerView.ViewHolder {

        TextView edtName, edtApellp;
        public MiniActivity(@NonNull @org.jetbrains.annotations.NotNull View itemView) {
            super(itemView);
            edtName = itemView.findViewById(R.id.textv1);
            edtApellp = itemView.findViewById(R.id.textv2);
        }
    }
}
