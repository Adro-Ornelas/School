package com.example.dental;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import Global.Info;
import Pojo.Dato;

public class Modificar extends AppCompatActivity {

    EditText edt_nombre,
            edt_apep,
            edt_apem,
            edt_tel,
            edt_proc,
            edt_horaAt,
            edt_fecha;
    Button btn_guardar, btn_anterior, btn_siguiente;
    Toolbar toolbar;

    SharedPreferences archivo;

    private int pos = 0;        // Posición inicial cero

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modificar);

        edt_nombre  = findViewById(R.id.edt_nombre);
        edt_apep    = findViewById(R.id.edt_apep);
        edt_apem    = findViewById(R.id.edt_apem);
        edt_tel     = findViewById(R.id.edt_telcontacto);
        edt_proc    = findViewById(R.id.edt_procedimiento);
        edt_horaAt  = findViewById(R.id.edt_horaAt);
        edt_fecha   = findViewById(R.id.edt_fecha);
        
        btn_anterior = findViewById(R.id.modif_btn_anterior);
        btn_guardar = findViewById(R.id.modif_btn_guardar);
        btn_siguiente = findViewById(R.id.modif_btn_siguiente);
        
        toolbar     = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Recibir información del cliente[0] en posición cero
        llenarCampos(pos);

        // EVENTOS DE BOTONES:
        btn_anterior.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                evento_anterior();
            }
        });
        btn_guardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                evento_guardarCambios();
            }
        });
        btn_siguiente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                evento_siguiente();
            }
        });
    }

    private void llenarCampos(int i) {

        edt_nombre.setText(Info.listaDato.get(i).getNombre());
        edt_apep.setText(Info.listaDato.get(i).getApellidoP());
        edt_apem.setText(Info.listaDato.get(i).getApellidoM());
        edt_tel.setText(Info.listaDato.get(i).getTelefonoCont());
        edt_proc.setText(Info.listaDato.get(i).getProcedimiento());
        edt_horaAt.setText(Info.listaDato.get(i).getHoraAt());
        edt_fecha.setText(Info.listaDato.get(i).getFecha());
    }

    // Inflar menu de toolbar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }
    // Configurar opciones de menu de toolbars
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if(item.getItemId() == R.id.opc_principal) {

            Intent aMain = new Intent(this, MainActivity.class);
            startActivity(aMain);

        } else if (item.getItemId() == R.id.opc_ver) {

            Intent aver = new Intent(this, ver.class);
            startActivity(aver);

        } else if (item.getItemId() == R.id.opc_modif) {

            Toast.makeText(this, "Ya estás aquí", Toast.LENGTH_SHORT).show();
        } else if (item.getItemId() == R.id.opc_delete) {

            Intent aEliminar = new Intent(this, Eliminar.class);
            startActivity(aEliminar);
        } else if(item.getItemId() == R.id.opc_cerrar_sesion){

            if(archivo.contains("id_user")){
                SharedPreferences.Editor editor = archivo.edit();
                editor.remove("id_user");
                editor.apply();
                editor.apply();
                // Navega a Inicio y finaliza
                Intent aInicio = new Intent(this, Inicio.class);
                startActivity(aInicio);
                finish();
            }
        }
        return super.onOptionsItemSelected(item);
    }


    private void evento_anterior() {
        // Decrementa posición
        --pos;
        if(pos == -1)   // Si posición -1 va a extremo superior
            pos = Info.listaDato.size() - 1;
        llenarCampos(pos);  // Lena con datos
    }

    private void evento_siguiente() {
        // Aumenta posición
        ++pos;
        if(pos == Info.listaDato.size())   // Si posición MAX va a extremo inferior
            pos = 0;
        llenarCampos(pos);  // Llena con datos
    }

    private void evento_guardarCambios() {

        // Establezco los atributo de la identidad
        Info.listaDato.get(pos).setNombre(edt_nombre.getText().toString());
        Info.listaDato.get(pos).setApellidoP(edt_apep.getText().toString());
        Info.listaDato.get(pos).setApellidoM(edt_apem.getText().toString());
        Info.listaDato.get(pos).setTelefonoCont(edt_tel.getText().toString());
        Info.listaDato.get(pos).setProcedimiento(edt_proc.getText().toString());
        Info.listaDato.get(pos).setHoraAt(edt_horaAt.getText().toString());
        Info.listaDato.get(pos).setFecha(edt_fecha.getText().toString());

        Toast.makeText(this, "ELEMENTO MODIFICADO", Toast.LENGTH_LONG).show();
    }

}
