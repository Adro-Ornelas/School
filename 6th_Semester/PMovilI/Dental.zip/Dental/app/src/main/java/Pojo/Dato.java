package Pojo;

public class Dato {

    String nombre;
    String apellidoP;
    String apellidoM;
    String telefonoCont;
    String procedimiento;
    String horaAt;
    String fecha;

    public int day, month, year;    // day, month, year
    public int hour, min;           // hour, minute

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidoP() {
        return apellidoP;
    }

    public void setApellidoP(String apellidoP) {
        this.apellidoP = apellidoP;
    }

    public String getApellidoM() {
        return apellidoM;
    }

    public void setApellidoM(String apellidoM) {
        this.apellidoM = apellidoM;
    }

    public String getTelefonoCont() {
        return telefonoCont;
    }

    public void setTelefonoCont(String telefonoCont) {
        this.telefonoCont = telefonoCont;
    }

    public String getProcedimiento() {
        return procedimiento;
    }

    public void setProcedimiento(String procedimiento) {
        this.procedimiento = procedimiento;
    }

    public String getHoraAt() {
        return horaAt;
    }

    public void setHoraAt(String horaAt) {
        this.horaAt = horaAt;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
}
