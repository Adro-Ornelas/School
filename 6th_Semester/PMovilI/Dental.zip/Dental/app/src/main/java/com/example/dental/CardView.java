package com.example.dental;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import Global.Info;

public class CardView extends AppCompatActivity {
    TextView txt_nombre,
             txt_apep,
             txt_apem,
             txt_tel,
             txt_proc,
             txt_horaAt,
             txt_fecha;
    Button   btn_llamar;
    Toolbar toolbar;

    SharedPreferences archivo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_card_view);

        // Asignar ID a objetos
        txt_nombre = (TextView) findViewById(R.id.cardtxtName);
        txt_apep   = (TextView) findViewById(R.id.cardtxtApeP);
        txt_apem   = (TextView) findViewById(R.id.cardtxtApeM);
        txt_tel    = (TextView) findViewById(R.id.cardtxtTelefon);
        txt_proc   = (TextView) findViewById(R.id.cardtxtProc);
        txt_horaAt = (TextView) findViewById(R.id.cardtxthoraA);
        txt_fecha  = (TextView) findViewById(R.id.cardtxtFecha);

        btn_llamar = (Button) findViewById(R.id.btn_llamar);

        // Set toolbar:
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        // SHARED PREFERENCES
        archivo = this.getSharedPreferences("sesion", Context.MODE_PRIVATE);

        // Recibir posicion de clase adaptadorver
        int pos = getIntent().getIntExtra("pos", -1);
        txt_nombre.setText(Info.listaDato.get(pos).getNombre());
        txt_apep.setText(Info.listaDato.get(pos).getApellidoP());
        txt_apem.setText(Info.listaDato.get(pos).getApellidoM());
        txt_tel.setText(Info.listaDato.get(pos).getTelefonoCont());
        txt_proc.setText(Info.listaDato.get(pos).getProcedimiento());
        txt_horaAt.setText(Info.listaDato.get(pos).getHoraAt());
        txt_fecha.setText(Info.listaDato.get(pos).getFecha());

        // ClickListener par a boton llamar
        btn_llamar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                eventoLlamar();
            }
        });
    }

    // Inflar menu de toolbar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }
    // Configurar opciones de menu de toolbars
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if(item.getItemId() == R.id.opc_principal) {
            Intent aMain = new Intent(this, MainActivity.class);
            startActivity(aMain);
        } else if (item.getItemId() == R.id.opc_ver) {
            Intent aver = new Intent(this, ver.class);
            startActivity(aver);
        } else if (item.getItemId() == R.id.opc_modif) {
            Intent aModif = new Intent(this, Modificar.class);
            startActivity(aModif);
        }  else if (item.getItemId() == R.id.opc_delete) {
            Intent aEliminar = new Intent(this, Eliminar.class);
            startActivity(aEliminar);
        } else if(item.getItemId() == R.id.opc_cerrar_sesion){
            if(archivo.contains("id_user")){
                SharedPreferences.Editor editor = archivo.edit();
                editor.remove("id_user");
                editor.apply();
                editor.apply();
                // Navega a Inicio y finaliza
                Intent aInicio = new Intent(this, Inicio.class);
                startActivity(aInicio);
                finish();
            }
        }
        return super.onOptionsItemSelected(item);
    }
    // Evento para boton llamar
    private void eventoLlamar() {
        Intent llamada = new Intent(Intent.ACTION_CALL);    // Intent como action call
        llamada.setData(Uri.parse("tel:"+txt_tel.getText().toString()));    // Uri para reconocer numero

        // SI no hay permiso para llamar, pedir permiso
        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE)
                != PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(this, new String[]
                    {Manifest.permission.CALL_PHONE}, 777); // Codigo de llamada
            return;
        }
        startActivity(llamada);
    }

}