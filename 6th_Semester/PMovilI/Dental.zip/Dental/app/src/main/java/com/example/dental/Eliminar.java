package com.example.dental;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import Adaptadores.adaptadoreliminar;
import Global.Info;
import Pojo.Dato;


public class Eliminar extends AppCompatActivity {

    Toolbar toolbar;
    RecyclerView recyclerView;
    Button botonEliminar;
    SharedPreferences archivo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eliminar);

        Context context;
        recyclerView = findViewById(R.id.recicladorEliminar);
        adaptadoreliminar miAdp = new adaptadoreliminar();

        miAdp.context = this;
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this,
                LinearLayoutManager.VERTICAL, false);

        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(miAdp);

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        botonEliminar = findViewById(R.id.btn_deleteClient);
        botonEliminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                evento_eliminar();
            }
        });

        // SHARED PREFERENCES
        archivo = this.getSharedPreferences("sesion", Context.MODE_PRIVATE);
    }

    private void evento_eliminar() {
        for(int i = 0; i < Info.listasBajas.size(); ++i){
            Dato persona = Info.listasBajas.get(i);
            Info.listaDato.remove(persona);
        }
        Info.listasBajas.clear();
        recyclerView.getAdapter().notifyDataSetChanged();
    }

    // Inflar menu de toolbar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }
    // Configurar opciones de menu de toolbars
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if(item.getItemId() == R.id.opc_principal) {
            Intent aMain = new Intent(this, MainActivity.class);
            startActivity(aMain);
        } else if (item.getItemId() == R.id.opc_ver) {
            Intent aVer = new Intent(this, ver.class);
            startActivity(aVer);
        } else if (item.getItemId() == R.id.opc_modif) {
            Intent aModif = new Intent(this, Modificar.class);
            startActivity(aModif);
        } else if (item.getItemId() == R.id.opc_delete) {
            Toast.makeText(this, "Ya estás aquí", Toast.LENGTH_SHORT).show();
        } else if(item.getItemId() == R.id.opc_cerrar_sesion){
            if(archivo.contains("id_user")){
                SharedPreferences.Editor editor = archivo.edit();
                editor.remove("id_user");
                editor.apply();
                editor.apply();
                // Navega a Inicio y finaliza
                Intent aInicio = new Intent(this, Inicio.class);
                startActivity(aInicio);
                finish();
            }
        }
        return super.onOptionsItemSelected(item);
    }
}