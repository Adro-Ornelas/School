package Global;

import java.util.ArrayList;
import Pojo.Dato;

public class Info {

    // Publico, static (constante), final (elementos se añaden al final)
    public static final ArrayList<Dato> listaDato = new ArrayList<>();

    public static final ArrayList<Dato> listasBajas = new ArrayList<>();
}
