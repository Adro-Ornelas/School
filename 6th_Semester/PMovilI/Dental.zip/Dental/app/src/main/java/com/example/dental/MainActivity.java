package com.example.dental;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.DatePickerDialog;
import android.app.DownloadManager;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import Global.Info;
import Pojo.Dato;

public class MainActivity extends AppCompatActivity {
    EditText    edt_nombre,
                edt_apep,
                edt_apem,
                edt_tel,
                edt_proc,
                edt_horaAt,
                edt_fecha;
    Button btn_guardar;
    Toolbar toolbar;
    SharedPreferences archivo;

    Dato nuevoCliente = new Dato();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edt_nombre  = findViewById(R.id.edt_nombre);
        edt_apep    = findViewById(R.id.edt_apep);
        edt_apem    = findViewById(R.id.edt_apem);
        edt_tel     = findViewById(R.id.edt_telcontacto);
        edt_proc    = findViewById(R.id.edt_procedimiento);
        edt_horaAt  = findViewById(R.id.edt_horaAt);
        edt_fecha   = findViewById(R.id.edt_fecha);
        btn_guardar = findViewById(R.id.edt_btn_guardar);
        toolbar     = findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);

        // Inicializa SharedPreferences
        archivo = this.getSharedPreferences("sesion", Context.MODE_PRIVATE);

        // Contructor (new), barra espaciador view on click listener
        // OnCLickListener para boton guardar
        btn_guardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                evento_guardar();       // Definir metodo
            }
        });
        // ClickListener para editText Hora
        edt_horaAt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                picker_hora();
            }
        });
        // ClickListener para editText Fecha
        edt_fecha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                picker_fecha();
            }
        });
    }

    // Dialog para hora
    private void picker_hora() {
        int h, m;   // hour, minute
        Calendar calendar = Calendar.getInstance();
        h = calendar.get(Calendar.HOUR_OF_DAY);
        m = calendar.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                nuevoCliente.hour = hourOfDay;
                nuevoCliente.min = minute;
                String cadena = "" + nuevoCliente.hour + ":" +
                        nuevoCliente.min;
                edt_horaAt.setText(cadena);
            }
        }, h, m, true); // Establece parámetros y formato 24 horas true
        timePickerDialog.show();    // Mostrar TimePickerD

    }

    // Dialog para fecha
    private void picker_fecha() {
        int d, m, y;    // day, month, year
        Calendar calendar = Calendar.getInstance();
        d = calendar.get(Calendar.DAY_OF_MONTH);
        m = calendar.get(Calendar.MONTH);
        y = calendar.get(Calendar.YEAR);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                nuevoCliente.day = dayOfMonth;
                nuevoCliente.month = month + 1;    // Porque cuente desde cero
                nuevoCliente.year = year;
                String cadena = "" + nuevoCliente.day + "/" +
                        nuevoCliente.month + "/" + nuevoCliente.year;
                edt_fecha.setText(cadena);
            }
        }, y, m, d);
        datePickerDialog.show();    // Mostrar datePickerD
    }

    // Inflar menu de toolbar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }
    // Configurar opciones de menu de toolbars
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if(item.getItemId() == R.id.opc_principal) {

            Toast.makeText(this, "Ya estás aquí", Toast.LENGTH_SHORT).show();

        } else if (item.getItemId() == R.id.opc_ver) {

            Intent aver = new Intent(this, ver.class);
            startActivity(aver);

        } else if (item.getItemId() == R.id.opc_modif) {

            // Sólo inicia nueva activty si hay datos a modificar
            if (Info.listaDato.isEmpty()) {

                Toast.makeText(this, "Agrega clientes para modifcarlos",
                        Toast.LENGTH_SHORT).show();
            } else {
                Intent aModif = new Intent(this, Modificar.class);
                startActivity(aModif);
            }

        } else if (item.getItemId() == R.id.opc_delete) {
            Intent aEliminar = new Intent(this, Eliminar.class);
            startActivity(aEliminar);
        } else if(item.getItemId() == R.id.opc_cerrar_sesion){

            if(archivo.contains("id_user")){
                SharedPreferences.Editor editor = archivo.edit();
                editor.remove("id_user");
                editor.apply();
                editor.apply();
                // Navega a Inicio y finaliza
                Intent aInicio = new Intent(this, Inicio.class);
                startActivity(aInicio);
                finish();


                /*  SIN BASE DE DATOS (SOLO SHAREDPREFERENCES)
                // Para cerrar sesión, borra las credenciales guardadas en el sharedPrefrences "sesion"
                SharedPreferences.Editor editor = archivo.edit();
                editor.remove("user");
                editor.remove("password");
                editor.remove("valid");
                editor.apply();
                // Navega a Inicio y finaliza
                Intent aInicio = new Intent(this, Inicio.class);
                startActivity(aInicio);
                finish();
                */

            }
        }
        return super.onOptionsItemSelected(item);
    }

    // Evento de boton guardar
    private void evento_guardar() {

        Dato nuevoC = new Dato();

        // Establezco los atributo de la identidad
        nuevoC.setNombre(edt_nombre.getText().toString());
        nuevoC.setApellidoP(edt_apep.getText().toString());
        nuevoC.setApellidoM(edt_apem.getText().toString());
        nuevoC.setTelefonoCont(edt_tel.getText().toString());
        nuevoC.setProcedimiento(edt_proc.getText().toString());
        nuevoC.setHoraAt(edt_horaAt.getText().toString());
        nuevoC.setFecha(edt_fecha.getText().toString());

        // Añado nueva entidad a ArrayList
        Info.listaDato.add(nuevoC);

        // Guardo en la base de datos
        RequestQueue requestQueue = Volley.newRequestQueue(this);

        StringRequest sql = new StringRequest(Request.Method.POST,
                "http://192.168.46.17/bd/insertar_cliente.php",
                new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                  //  Log.d("NO paso", response);
                    Toast.makeText(MainActivity.this, response, Toast.LENGTH_SHORT).show();
                }
            }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("NO paso", error.getMessage());
                Toast.makeText(MainActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @Nullable
            @org.jetbrains.annotations.Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> x = new HashMap<>();
                x.put("nombre", "" + nuevoC.getNombre());
                x.put("apep", "" + nuevoC.getApellidoP());
                x.put("apem", "" + nuevoC.getApellidoM());
                x.put("tel", "" + nuevoC.getTelefonoCont());
                x.put("proc", "" + nuevoC.getProcedimiento());
                x.put("hora", "" + nuevoC.getHoraAt());
                x.put("fecha", "" + nuevoC.getFecha());
                return x;
                //return super.getParams();
            }
        };
        requestQueue.add(sql);

        // Mensaje de confirmación
        //Toast.makeText(MainActivity.this, "ELEMENTO AÑADIDO", Toast.LENGTH_LONG).show();
    }
}