package com.example.dental;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class Inicio extends AppCompatActivity {
    TextView edt_usr, edt_passwd;
    Button buttonLogin;
    SharedPreferences archivo;
    Toolbar toolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio);

        // Asignar id
        edt_usr = (EditText) findViewById(R.id.edt_usuario);
        edt_passwd = (EditText) findViewById(R.id.edt_contrasena);

        // Toolbar
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        buttonLogin = findViewById(R.id.btn_loggin);
        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                evento_login();
            }
        });

        // SHARED PREFERENCES
        archivo = this.getSharedPreferences("sesion", Context.MODE_PRIVATE);

        // SI ya hay usuario, cierra aplicación
        if(archivo.contains("usuario")){

            // Navega a MainActiviry
            Intent aMain = new Intent(this, MainActivity.class);
            startActivity(aMain);
            finish();
        }
    }

    // Evento del boton INICIAR
    private void evento_login() {

        String url = "http://192.168.46.17/bd/" +
                "ingreso.php?usr=";
        url = url + edt_usr.getText().toString();
        url = url + "&pass=";
        url = url + edt_passwd.getText().toString();


        JsonObjectRequest pet = new JsonObjectRequest(Request.Method.GET,
                url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    if (response.getInt("usr") != -1) {
                        Intent in = new Intent(Inicio.this, MainActivity.class);
                        // Subo a SharedPreferences la ID del usuario
                        SharedPreferences.Editor editor = archivo.edit();
                        editor.putInt("id_user", response.getInt("usr"));
                        editor.apply();
                        Toast.makeText(Inicio.this, ""+archivo.getInt("id_user", 0), Toast.LENGTH_SHORT).show();
                        startActivity(in);

                        finish();
                    } else {
                        edt_usr.setText("");
                        edt_passwd.setText("");
                        //Toast.makeText(Inicio.this, "Usuario o contraseña incorrectos", Toast.LENGTH_SHORT).show();
                    }

                } catch (JSONException e) {
                    throw new RuntimeException(e);
                }
                Toast.makeText(Inicio.this, response.toString(), Toast.LENGTH_SHORT).show();

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error)
            {
                Log.d("yo", error.getMessage());
                // edt_passwd.setText(error.getMessage());
                Toast.makeText(Inicio.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        RequestQueue peticion = Volley.newRequestQueue(this);
        peticion.add(pet);

        /*
        if(edt_usr.getText().toString().equals("Adro") &&
            edt_passwd.getText().toString().equals("12345")){


            /*

            // Añade datos a SharedPreferences
            SharedPreferences.Editor editor = archivo.edit();
            editor.putString("user", "Adro");
            editor.putString("password", "12345");
            editor.putBoolean("valid", true);
            editor.apply();

            // Navega a MainActiviry
            Intent aMain = new Intent(this, MainActivity.class);
            startActivity(aMain);

            finish();

        } else {
            edt_usr.setText("");
            edt_passwd.setText("");
            Toast.makeText(this, "CREDENCIALES NO VÁLIDAS", Toast.LENGTH_SHORT).show();
        }

             */
    }
    // NO OPTION MENU DE TOOLBAR
}