package com.example.dental;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import Adaptadores.adaptadorver;

public class ver extends AppCompatActivity {

    Toolbar toolbar;
    RecyclerView recyclerView;

    SharedPreferences archivo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ver);

        Context context;
        recyclerView = findViewById(R.id.reciclador);
        adaptadorver miaver = new adaptadorver();

        miaver.context = this;
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this,
                LinearLayoutManager.VERTICAL, false);

        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(miaver);
        
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        // SHARED PREFERENCES
        archivo = this.getSharedPreferences("sesion", Context.MODE_PRIVATE);
    }
    // Inflar menu de toolbar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }
    // Configurar opciones de menu de toolbars
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if(item.getItemId() == R.id.opc_principal) {

            Intent aMain = new Intent(this, MainActivity.class);
            startActivity(aMain);

        } else if (item.getItemId() == R.id.opc_ver) {

            Toast.makeText(this, "Ya estás aquí", Toast.LENGTH_SHORT).show();

        } else if (item.getItemId() == R.id.opc_modif) {

            Intent aModif = new Intent(this, Modificar.class);
            startActivity(aModif);

        } else if (item.getItemId() == R.id.opc_delete) {

            Intent aEliminar = new Intent(this, Eliminar.class);
            startActivity(aEliminar);
        } else if(item.getItemId() == R.id.opc_cerrar_sesion){

            if(archivo.contains("id_user")){
                SharedPreferences.Editor editor = archivo.edit();
                editor.remove("id_user");
                editor.apply();
                editor.apply();
                // Navega a Inicio y finaliza
                Intent aInicio = new Intent(this, Inicio.class);
                startActivity(aInicio);
                finish();
            }
        }

        return super.onOptionsItemSelected(item);
    }
}